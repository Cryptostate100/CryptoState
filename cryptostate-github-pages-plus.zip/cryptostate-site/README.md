# Crypto State — GitHub Pages Package (with Analytics & Snippets)

Pre‑configured for **GitHub Pages** at **https://cryptostate.com**.

## Included
- `CNAME`, `.nojekyll`, `404.html`
- `robots.txt`, `sitemap.xml`
- `assets/js/analytics.js` → set `window.GA_MEASUREMENT_ID='G-XXXXXXX'`
- `assets/js/snippets.js` → uncomment a chat/pixel snippet and add your keys

## Deploy
1. Create a GitHub repo (e.g., `cryptostate-site`), commit all files to `main` root.
2. Repo **Settings → Pages** → Source: `Deploy from a branch`, Branch: `main` `/root`.
3. Set **Custom domain** to `cryptostate.com`.
4. DNS at your registrar:
   - A `@` → 185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153
   - CNAME `www` → `<your-username>.github.io`
5. In `assets/js/analytics.js`, set your GA4 ID. Uncomment any chat/pixel in `assets/js/snippets.js`.

Done 🎉
