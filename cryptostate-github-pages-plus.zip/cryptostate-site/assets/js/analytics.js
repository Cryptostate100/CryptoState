
// Set your Google Analytics 4 ID here, e.g. 'G-XXXXXXX'
window.GA_MEASUREMENT_ID = window.GA_MEASUREMENT_ID || 'G-XXXXXXX';

(function(){
  var ID = window.GA_MEASUREMENT_ID;
  if(!ID || ID==='G-XXXXXXX') { console.warn('Analytics disabled: set GA_MEASUREMENT_ID in assets/js/analytics.js'); return; }
  var s=document.createElement('script');
  s.async=true; s.src='https://www.googletagmanager.com/gtag/js?id='+ID;
  document.head.appendChild(s);
  window.dataLayer=window.dataLayer||[];
  function gtag(){ dataLayer.push(arguments); }
  window.gtag = gtag;
  gtag('js', new Date());
  gtag('config', ID);
})();
