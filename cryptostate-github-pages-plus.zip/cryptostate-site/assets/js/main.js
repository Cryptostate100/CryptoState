
function toggleMenu(){
  const nav = document.querySelector('.nav');
  if(nav.style.display==='flex'){ nav.style.display='none'; }
  else { nav.style.display='flex'; nav.style.flexDirection='column'; nav.style.gap='10px'; }
}
function fakeLogin(role){ alert(`Logged into ${role} demo! (Front‑end only)`); }
function mockConnectWallet(){ document.getElementById('walletStatus').textContent = 'Wallet connected: 0xAbC...123 (demo)'; }
function mockKYC(){ document.getElementById('kycStatus').textContent = 'KYC approved (demo) — wallet whitelisted'; }
function mockBuy(){ document.getElementById('buyStatus').textContent = 'Order placed: 2,500 tokens @ $10 — settlement pending (demo)'; }
function simulateTransfer(){
  const from = document.getElementById('fromAddr').value || '0xFrom';
  const to = document.getElementById('toAddr').value || '0xTo';
  const amt = Number(document.getElementById('amt').value || 0);
  let msg = '';
  if(amt <= 0) msg = 'Enter amount.';
  else if(from === to) msg = 'Sender and recipient cannot be the same.';
  else msg = `Transfer permitted (demo): ${amt} tokens from ${from} → ${to}`;
  document.getElementById('ruleStatus').textContent = msg;
}
function submitForm(){ document.getElementById('formStatus').textContent = 'Thanks! We will reach out within 1 business day (demo).'; }
